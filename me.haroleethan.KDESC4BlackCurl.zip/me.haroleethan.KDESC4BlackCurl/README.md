# me.haroleethan.KDESC4Elarun
This is a recreation of the final version of KDE SC 4's Splash Screen and is meant to look almost one to one with the original.

# Installation
Move this folder (me.haroleethan.KDESC4Black) into /home/$USER/.local/share/plasma/look-and-feel (create the directory for look-and-feel if you don't see it)

or if you want it system-wide, place it in /usr/share/plasma/look-and-feel
